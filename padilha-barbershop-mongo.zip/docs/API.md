# Documentação da API - Padilha Barbershop

(Arquivo gerado a partir da documentação fornecida.)
