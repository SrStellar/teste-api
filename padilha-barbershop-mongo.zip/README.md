# Padilha Barbershop API (MongoDB + Joi + Docker)

### Como usar
1. Copie `.env.example` para `.env` e ajuste se necessário.
2. Rode com Docker Compose:
   ```bash
   docker-compose up --build
   ```
3. A API estará disponível em `http://localhost:3000`.

### Endpoints principais (resumo)
- `GET /api/v1/barbers`
- `GET /api/v1/services`
- `GET /api/v1/gallery`
- `GET /api/v1/contact-info`
- `GET /api/v1/appointments/availability?barberId=...&date=YYYY-MM-DD`
- Auth:
  - `POST /api/v1/auth/register`
  - `POST /api/v1/auth/login`
  - `POST /api/v1/auth/logout`

### Observações
- Projeto usa MongoDB via Mongoose.
- Validação de entrada com Joi.
- Autenticação JWT.
- Troque a persistência e ajustes conforme sua necessidade.
