const mongoose = require('mongoose');

const barberSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  name: { type: String, required: true },
  specialty: { type: String },
  experience: { type: String },
  imageUrl: { type: String }
}, { timestamps: true });

module.exports = mongoose.model('Barber', barberSchema);
