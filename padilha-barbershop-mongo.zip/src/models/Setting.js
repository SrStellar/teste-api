const mongoose = require('mongoose');

const settingSchema = new mongoose.Schema({
  phone: String,
  email: String,
  address: String,
  socials: { type: Object }
}, { timestamps: true });

module.exports = mongoose.model('Setting', settingSchema);
