const mongoose = require('mongoose');
require('dotenv').config();
const connectDB = require('./config/db');
const User = require('./models/User');
const Barber = require('./models/Barber');
const ServiceCategory = require('./models/ServiceCategory');
const GalleryItem = require('./models/GalleryItem');
const Setting = require('./models/Setting');
const bcrypt = require('bcryptjs');

(async () => {
  await connectDB();
  const adminEmail = 'admin@padilha.com';
  let admin = await User.findOne({ email: adminEmail });
  if (!admin) {
    const hash = await bcrypt.hash('admin123', 10);
    admin = await User.create({ name: 'Admin', email: adminEmail, password: hash, role: 'admin' });
    console.log('Admin criado:', adminEmail);
  } else {
    console.log('Admin já existe.');
  }

  const b = await Barber.findOne();
  if(!b) await Barber.create({ name: 'Carlos Almeida', specialty: 'Cortes Clássicos', experience: '10+ anos', imageUrl: '' });

  const cat = await ServiceCategory.findOne();
  if(!cat) {
    await ServiceCategory.create({ name: 'Cabelo', services: [{ id:801, name:'Corte Tradicional', price:50 }, { id:802, name:'Corte na Tesoura', price:60 }]});
  }

  const g = await GalleryItem.findOne();
  if(!g) await GalleryItem.create({ title: 'Corte Degradê Navalhado', description: 'Acabamento preciso com degradê suave.', imageUrl: '' });

  const s = await Setting.findOne();
  if(!s) await Setting.create({ phone:'(11) 98765-4321', email:'contato@padilhabarbershop.com', address:'Rua das Navalhas, 123', socials:{ instagram:'#' }});

  console.log('Seed finalizado.');
  process.exit(0);
})();
