const Joi = require('joi');

const createAppointment = Joi.object({
  barberId: Joi.string().required(),
  serviceIds: Joi.array().items(Joi.number().required()).min(1).required(),
  date: Joi.string().pattern(/^\d{4}-\d{2}-\d{2}$/).required(),
  time: Joi.string().pattern(/^\d{2}:\d{2}$/).required(),
  notes: Joi.string().allow('', null)
});

module.exports = { createAppointment };
