const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const validate = require('../middlewares/validate');
const { register, login } = require('../validations/auth.validation');

const router = express.Router();

router.post('/register', validate(register), async (req, res) => {
  try {
    const { name, email, password } = req.body;
    const exists = await User.findOne({ email });
    if (exists) return res.status(400).json({ message: 'Este email já está em uso.' });
    const hash = await bcrypt.hash(password, 10);
    const user = await User.create({ name, email, password: hash, role: 'customer' });
    const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET || 'changeme123', { expiresIn: process.env.JWT_EXPIRES_IN || '1d' });
    res.status(201).json({ user: { id: user._id, name: user.name, email: user.email, role: user.role }, tokens: { accessToken: token }});
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.post('/login', validate(login), async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(401).json({ message: 'Credenciais inválidas.' });
    const ok = await bcrypt.compare(password, user.password);
    if (!ok) return res.status(401).json({ message: 'Credenciais inválidas.' });
    const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET || 'changeme123', { expiresIn: process.env.JWT_EXPIRES_IN || '1d' });
    res.json({ user: { id: user._id, name: user.name, email: user.email, role: user.role }, tokens: { accessToken: token }});
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.post('/logout', (req, res) => res.status(204).send());

module.exports = router;
