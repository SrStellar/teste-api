const express = require('express');
const router = express.Router();
const Barber = require('../models/Barber');
const ServiceCategory = require('../models/ServiceCategory');
const GalleryItem = require('../models/GalleryItem');
const Setting = require('../models/Setting');
const Appointment = require('../models/Appointment');

router.get('/barbers', async (req, res) => {
  const list = await Barber.find();
  res.json(list);
});

router.get('/services', async (req, res) => {
  const list = await ServiceCategory.find();
  res.json(list);
});

router.get('/gallery', async (req, res) => {
  const list = await GalleryItem.find();
  res.json(list);
});

router.get('/contact-info', async (req, res) => {
  const info = await Setting.findOne();
  res.json(info || {});
});

router.get('/appointments/availability', async (req, res) => {
  const barberId = req.query.barberId;
  const date = req.query.date;
  if (!barberId || !date) return res.status(400).json({ message: 'barberId and date are required.' });
  const taken = await Appointment.find({ barberId, date }).select('time -_id');
  res.json(taken.map(t => t.time));
});

module.exports = router;
