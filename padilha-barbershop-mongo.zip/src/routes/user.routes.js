const express = require('express');
const router = express.Router();
const { authMiddleware } = require('../middlewares/auth');
const Appointment = require('../models/Appointment');
const Barber = require('../models/Barber');
const ServiceCategory = require('../models/ServiceCategory');
const validate = require('../middlewares/validate');
const { createAppointment } = require('../validations/appointment.validation');

router.use(authMiddleware());

router.get('/appointments', async (req, res) => {
  const list = await Appointment.find({ userId: req.user._id });
  res.json(list);
});

router.post('/appointments', validate(createAppointment), async (req, res) => {
  try {
    const { barberId, serviceIds, date, time, notes } = req.body;
    const barber = await Barber.findById(barberId);
    if (!barber) return res.status(400).json({ message: 'Barbeiro não encontrado.' });
    // collect services
    const categories = await ServiceCategory.find();
    const services = [];
    let total = 0;
    for (const c of categories) {
      for (const s of c.services) {
        if (serviceIds.includes(s.id)) { services.push(s); total += s.price; }
      }
    }
    const ap = await Appointment.create({
      userId: req.user._id,
      clientName: req.user.name,
      barberId,
      barberName: barber.name,
      date,
      time,
      services,
      totalPrice: total,
      notes
    });
    res.status(201).json(ap);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.delete('/appointments/:id', async (req, res) => {
  const id = req.params.id;
  const ap = await Appointment.findOne({ _id: id, userId: req.user._id });
  if (!ap) return res.status(404).json({ message: 'Agendamento não encontrado.' });
  ap.status = 'cancelled';
  await ap.save();
  res.status(204).send();
});

module.exports = router;
