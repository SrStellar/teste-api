const express = require('express');
const router = express.Router();
const { authMiddleware } = require('../middlewares/auth');
const User = require('../models/User');
const Barber = require('../models/Barber');
const ServiceCategory = require('../models/ServiceCategory');
const GalleryItem = require('../models/GalleryItem');
const Setting = require('../models/Setting');
const Appointment = require('../models/Appointment');

router.use(authMiddleware(['admin']));

router.get('/appointments', async (req, res) => res.json(await Appointment.find()));
router.get('/users', async (req, res) => res.json(await User.find().select('-password')));
router.delete('/users/:id', async (req, res) => { await User.deleteOne({ _id: req.params.id }); res.status(204).send(); });

// barbers
router.get('/barbers', async (req, res) => res.json(await Barber.find()));
router.post('/barbers', async (req, res) => {
  const b = await Barber.create(req.body);
  res.status(201).json(b);
});
router.put('/barbers/:id', async (req, res) => {
  const b = await Barber.findByIdAndUpdate(req.params.id, req.body, { new: true });
  if (!b) return res.status(404).json({ message: 'Barbeiro não encontrado.' });
  res.json(b);
});
router.delete('/barbers/:id', async (req, res) => { await Barber.findByIdAndDelete(req.params.id); res.status(204).send(); });

// categories & services
router.post('/service-categories', async (req,res) => {
  const c = await ServiceCategory.create(req.body);
  res.status(201).json(c);
});
router.put('/service-categories/:id', async (req,res)=> {
  const c = await ServiceCategory.findByIdAndUpdate(req.params.id, { name: req.body.name }, { new: true });
  if(!c) return res.status(404).json({ message: 'Categoria não encontrada.'});
  res.json(c);
});
router.delete('/service-categories/:id', async (req,res)=> { await ServiceCategory.findByIdAndDelete(req.params.id); res.status(204).send(); });

router.post('/services', async (req,res)=> {
  const { categoryId, name, price } = req.body;
  const c = await ServiceCategory.findById(categoryId);
  if(!c) return res.status(400).json({ message: 'Categoria inválida.'});
  const id = (Math.max(0, ...c.services.map(s=>s.id))||800) + 1;
  c.services.push({ id, name, price });
  await c.save();
  res.status(201).json(c);
});
router.put('/services/:id', async (req,res)=> {
  const id = Number(req.params.id);
  const c = await ServiceCategory.findOne({ 'services.id': id });
  if(!c) return res.status(404).json({ message: 'Serviço não encontrado.'});
  const s = c.services.id(c.services.find(s=>s.id===id)._id);
  Object.assign(s, req.body);
  await c.save();
  res.json(s);
});
router.delete('/services/:id', async (req,res)=> {
  const id = Number(req.params.id);
  const c = await ServiceCategory.findOne({ 'services.id': id });
  if(!c) return res.status(404).json({ message: 'Serviço não encontrado.'});
  c.services = c.services.filter(s=>s.id!==id);
  await c.save();
  res.status(204).send();
});

// gallery
router.post('/gallery', async (req,res)=> { const g = await GalleryItem.create(req.body); res.status(201).json(g); });
router.put('/gallery/:id', async (req,res)=> { const g = await GalleryItem.findByIdAndUpdate(req.params.id, req.body, { new: true }); if(!g) return res.status(404).json({ message: 'Item não encontrado.'}); res.json(g); });
router.delete('/gallery/:id', async (req,res)=> { await GalleryItem.findByIdAndDelete(req.params.id); res.status(204).send(); });

// settings
router.put('/contact-info', async (req,res)=> {
  let s = await Setting.findOne();
  if(!s) s = await Setting.create(req.body);
  else Object.assign(s, req.body) && await s.save();
  res.json(s);
});

module.exports = router;
